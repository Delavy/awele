=====================================================================================
= Rendu du projet d'awele par Nivoix Ludovic & Delaby Pierre
=====================================================================================

Cette archive contient : 
* botSimple  : les fichiers pour executer notre bot
	* dpln.bot.NIVOIXDELABY.R : contient le bot que nous rendons pour le championnat: dpln.nivoixdelaby (le fichier charge simplement le bot adlkiller sous le nom nivoixdelaby)
	!! attention, pour fonctionner il nécessite d'avoir awele.data dans le même repertoire (chargement d'awele.data fait dans dpln.bot.adlsupp.R)
	* dpln.bot.adlsupp.R : contient le code du bot adlkiller
	* dpln.addData.R : fichier de classe dataSupp nécessaire pour adlkiller

* botsComplets : les fichiers avec tous les bots, commentés, que nous avons créés afin de mener ce projet à bien
	Y sont inclus les fichiers que vous nous avez envoyé de match, ainsi que awele.R.
	Les classes les plus intéressantes sont : 
	* multibot
	* addData
	* svm
	* adlsupp

	
	
	
			  .-=========-.
              \'-=======-'/
              _|   .=.   |_
             ((|   DPLN  |))
              \|   /|\   |/
               \__ '`' __/
                 _`) (`_
			   _/_______\_
              /AWELE - CUP\
             /_____________\
			   
		*** Bon championnat ! ***