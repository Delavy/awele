####################################
#   Bot pour le match d'awele
#   Delaby Pierre & Nivoix Ludovic
###################################

# Chargement de la source du bot
source("dpln.bot.adlsupp.R")

# Choix du bot
dpln.nivoixdelaby = dpln.adlkiller
